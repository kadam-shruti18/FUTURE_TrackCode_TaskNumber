import React, { useState } from "react";
import { Link } from "react-router-dom";

 
 
const Checkout = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    address: "",
    phone: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    
    if (!form.name || !form.email || !form.address || !form.phone) {
      alert("Please fill all the fields.");
      return;
    }

    alert("✅ Order Placed Successfully!");
    
  };

  return (

    
    <div className="max-w-xl mx-auto p-6">
       
       

      <h1 className="text-2xl font-bold mb-6 text-center">Checkout</h1>
      
      <div className="backhome">
         <Link
          to="/"
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
         ⬅️ Back to Home
         </Link>
        </div>
        
      <form onSubmit={handleSubmit} className="container">
        <input
          type="text"
          name="name"
          placeholder="Full Name"
          value={form.name}
          onChange={handleChange}
          className="checkout"
          required
        /> <br />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          className="checkout"
          required
        /> <br />
        <input
          type="text"
          name="address"
          placeholder="Address"
          value={form.address}
          onChange={handleChange}
          className="checkout"
          required
        /><br />
        <input
          type="tel"
          name="phone"
          placeholder="Phone Number"
          value={form.phone}
          onChange={handleChange}
          className="checkout"
          required
        /> <br />
        <button
          type="submit"
          className="checkout"
        >
          Place Order
        </button>
      </form>
      

    </div>
  );
};

export default Checkout;
