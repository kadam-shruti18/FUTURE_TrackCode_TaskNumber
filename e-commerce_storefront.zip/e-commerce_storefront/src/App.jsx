import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from "react-router-dom";
import { CartProvider } from "./context/CartContext";
import Cart from "./components/Cart";
import ProductList from "./components/ProductList";
import Checkout from "./pages/Checkout";

function Layout() {
  const location = useLocation();
  const isCartPage = location.pathname === "/cart";
  const isCheckoutPage = location.pathname === "/checkout";


  return (
    <div className="min-h-screen bg-gray-100 p-4">
      
      {!isCartPage && !isCheckoutPage &&(
        <>
          <h1 className="text-3xl font-bold text-center mb-6">🛍️ My Mini Store</h1>
          <nav className="mb-4 text-center">
            <Link to="/cart" className="view">
             🛒 View Cart
            </Link>
          </nav>
        </>
      )}

      
      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <Router>
        <Layout />
      </Router>
    </CartProvider>
  );
}
