
export const products = [
  {
    id: 1,
    name: "Hydrating Facial Mist",
    price: 1200,
    description: "Refreshes and hydrates your skin instantly.",
    image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=400&q=80",
  },
   {
    id: 2,
    name: "Hydrating Facial Mist",
    price: 1200,
    description: "Refreshes and hydrates your skin instantly.",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: 3,
    name: "Natural Clay Mask",
    price: 1800,
    description: "Detoxifies and purifies skin for a fresh look.",
    image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=400&q=80",
  },
  {
    id: 4,
    name: "Gentle Face Cleanser",
    price: 900,
    description: "Removes impurities without drying skin.",
    image: "https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=400&q=80",
  },
  {
    id: 5,
    name: "SPF 50 Sunscreen",
    price: 1500,
    description: "Protects skin from harmful UV rays.",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80",
  },
  {
    id: 6,
    name: "Moisturizing Night Cream",
    price: 2200,
    description: "Nourishes skin deeply overnight.",
    image: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=400&q=80",
  },
  
 {
    id: 7,
    name: "SPF 50 Sunscreen",
    price: 1500,
    description: "Protects skin from harmful UV rays.",
    image: "https://images.unsplash.com/photo-1526045612212-70caf35c14df?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: 7,
    name: "Aloe Vera Gel",
    price: 800,
    description: "Soothes and moisturizes irritated skin.",
    image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: 8,
    name: "Rose Water Toner",
    price: 950,
    description: "Refreshes skin and tightens pores.",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80"
  },
  
  
];
