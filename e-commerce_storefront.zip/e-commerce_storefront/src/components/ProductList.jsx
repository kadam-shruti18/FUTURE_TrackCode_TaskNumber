// src/components/ProductList.jsx
import React, { useState } from 'react';
import { products } from '../data/products'; // Aapke products ka data
import ProductCard from './ProductCard';
import { useCart } from '../context/CartContext';
import SearchBar from './SearchBar';

const ProductList = () => {
  const { addToCart } = useCart();
  const [searchTerm, setSearchTerm] = useState('');

  // Search term ke basis par products ko filter karna
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      
      <div className="imageset">
        {filteredProducts.length > 0 ? (
          filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} addToCart={addToCart} />
          ))
        ) : (
          <p>No products found</p>
        )}
      </div>
    </div>
  );
};

export default ProductList;
