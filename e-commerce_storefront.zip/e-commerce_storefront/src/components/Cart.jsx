import React from "react";
import { useCart } from "../context/CartContext";
import { Link } from "react-router-dom";


const Cart = () => {
  const { cart, removeFromCart, clearCart, addToCart } = useCart();

  const totalPrice = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6 text-center">🛒 Your Cart</h1>

    <div className="backhome">
      <Link
       to="/"
        className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
       >
        ⬅️ Back to Home
       </Link>
      </div>

      <Link
       to="/checkout"
       className="checklink"
       >
         Proceed to Checkout
      </Link>


      {cart.length === 0 ? (
        <p className="yourcart">Your cart is empty.</p>
      ) : (
        <>
          {/* Product Cards Grid */}
          <div className="imageset">
            {cart.map((item) => (
              <div key={item.id} className="product-card">
                <img
                  src={item.image}
                  alt={item.name}
                  style={{ width: "200px", height: "200px", objectFit: "cover" }}
                />
                <p className="font-semibold mt-2">{item.name}</p>
                <p className="text-gray-600 mb-2">
                  ₹{item.price} x {item.quantity}
                </p>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="px-3 py-1 bg-red-500 text-white rounded"
                  >
                    -
                  </button>
                  <span className="font-bold">{item.quantity}</span>
                  <button
                    onClick={() => addToCart(item)}
                    className="px-3 py-1 bg-green-500 text-white rounded"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Total and Clear Cart */}
          <div className="mt-6 text-right pr-4">
            <p className="text-xl font-bold mb-2">Total: ₹{totalPrice}</p>
            <button
              onClick={clearCart}
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
            >
              Clear Cart
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
