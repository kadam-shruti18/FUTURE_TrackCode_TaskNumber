content: ["./index.html", "./src/**/*.{js,jsx}"]
